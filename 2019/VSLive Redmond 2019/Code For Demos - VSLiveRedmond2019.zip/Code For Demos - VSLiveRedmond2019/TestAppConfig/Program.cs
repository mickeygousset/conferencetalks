﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

using Microsoft.Extensions.Configuration.AzureAppConfiguration;

namespace TestAppConfig
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateWebHostBuilder(args).Build().Run();
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .ConfigureAppConfiguration((hostingContext, config) =>
                {
                    var settings = config.Build();
                    config.AddAzureAppConfiguration(options =>
                    {
                        options.ConnectWithManagedIdentity("https://<ADD YOUR CONFIG NAME HERE>.azconfig.io")
                            .Use(keyFilter: "TestApp:*")
                            .ConfigureRefresh(refresh =>
                            {
                                refresh.Register("TestApp:Settings:BackgroundColor")
                                       .Register("TestApp:Settings:FontColor")
                                       .Register("TestApp:Settings:Message")
                                       .SetCacheExpiration(TimeSpan.FromSeconds(5));

                            })
                            .UseFeatureFlags(featureFlagOptions =>
                            {
                                featureFlagOptions.CacheExpirationTime = TimeSpan.FromSeconds(5);
                            });

                    });
                })
                .UseStartup<Startup>();
    }
}
