﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PoorMansFeatureFlags.Flags
{
    public class MyFeatureToggle : FeatureToggle.RandomFeatureToggle
    {
    }
}